Syntax: java -jar proxy.jar [options]

Where options are:

-p : Port used by the server. By default if this option is not given, the 8080 port will be used instead. 
	Example : -p 9090

-d : Directory of cache system, by default the folder is set to "cache". 
	Example : -d myCache